//
//  CyberScapeApp.swift
//  CyberScapeFinal
//
//  Created by Armela Cupi on 18/04/2024.
//

import SwiftUI

@main
struct CyberScapeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
