#  CyberScape Project

Hardware Requirements:

To run and demonstrate this project effectively, ensure you have the following setup:

1)iPhone: The project is optimized for use on an iPhone.
2)USB-C Cable: A USB-C cable is required to connect the iPhone to your laptop. This connection is necessary for the proper execution and demonstration of the project.


Setup Instructions:

1)Connect Your iPhone to Your Laptop: Use the USB-C cable to connect your iPhone to your laptop. This setup is crucial for the software to function as designed.
2)Running the Project: With the iPhone connected, select the iphone you using on swiftui and then run the project.

Please ensure the connection between your iPhone and laptop is secure during demonstrations to avoid any disruptions.

For the sign in add these details:
email: user@example.com 
password: password

When adding the date of birth, I have created it for adults, so should be 18+.
